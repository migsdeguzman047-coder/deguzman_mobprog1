import 'package:flutter/material.dart';
import '../widgets/newsfeed_card.dart';

class NewsfeedScreen extends StatelessWidget {
  const NewsfeedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: const [
        NewsfeedCard(
          userName: 'bossing',
          postContent: 'isang libo',
          date: '21 min ago',
          numOfLikes: 1000000000000000000,
        ),
        NewsfeedCard(
          userName: 'vic sotto',
          postContent: 'presidente ng pasig',
          date: 'February 31, 2023',
          numOfLikes: 2,
          hasImage: true,
        ),
      ],
    );
  }
}